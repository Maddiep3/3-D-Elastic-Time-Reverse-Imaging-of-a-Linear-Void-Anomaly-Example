from rsf.proj import *

par = {
 'RSF':'/sets/cwp/code/RSF/RSF4.2_CU12.9.1/bin/',
}

# . .vplot 
v2e = ' /sets/cwp/code/RSF/RSF4.2_CU12.9.1/bin/vplot2eps color=y invras=n '

greyplot = ' pclip=99.85 screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m labelsz=4 font=104 '

def DispersionPanel_Bandpass(dpdata, pad, win, dt, minVel, maxVel, dVel,
                              fmin, fmax, flo, fhi, flevel, fsmo, title, greypar):
    par.update(dict(dppad=pad, dpwin=win, dpdt=dt, dpminv=minVel, dpmaxv=maxVel,
                    dpdv=dVel, dpfmin=fmin, dpfmax=fmax+10,
                    flo=flo, fhi=fhi, flevel=flevel, fsmo=fsmo, dptitle=title))
    Result(dpdata, '''
        pad n1=%(dppad)d | fft1 |
        window n1=%(dpwin)d n2=72 |
        %(ABIN)s/sfdispersion_bp_CL
            dt=%(dpdt)g flo=%(flo)g fhi=%(fhi)g flevel=%(flevel)g fsmooth=%(fsmo)d
            minVel=%(dpminv)g maxVel=%(dpmaxv)g dVel=%(dpdv)g |
        window min2=%(dpfmin)g max2=%(dpfmax)g |
        grey title=%(dptitle)s''' % par + greypar)

for itag in ['050','075','100','125','150','a20_100','m20_100']:

	Plot('yumaIC_'+itag+'m','./2D_yuma_'+itag+'m/imagenosmo.rsf','''
		pow pow1=0.325 | window min2=-22.5 max2=22.5 max1=22.5 | 
		%(RSF)s/sfgrey color=IC '''%par + greyplot)
	Flow('yumaIC_'+itag+'m.eps','yumaIC_'+itag+'m.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	Plot('yuma_'+itag+'m','./2D_yuma_'+itag+'m/imagenosmo.rsf','''
		window min2=-22.5 max2=22.5 max1=22.5 | %(RSF)s/sfgrey '''%par + greyplot)
	Flow('yuma_'+itag+'m.eps','yuma_'+itag+'m.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)
	
	Plot('vst_'+itag+'m','./2D_yuma_'+itag+'m/vst.rsf','''
		window min2=-22.5 max2=22.5 max1=22.5 | %(RSF)s/sfgrey color=j'''%par + greyplot)
	Flow('vst_'+itag+'m.eps','vst_'+itag+'m.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	#Dispersion Panels


End()
