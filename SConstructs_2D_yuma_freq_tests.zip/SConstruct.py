from rsf.proj import *

par = {
 'RSF':'/sets/cwp/code/RSF/RSF4.2_CU12.9.1/bin/',
}

# . .vplot 
v2e = ' /sets/cwp/code/RSF/RSF4.2_CU12.9.1/bin/vplot2eps color=y invras=n '

greyplot = ' pclip=99.85 screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m labelsz=4 font=104 '

for itag in ['10_50','5_35']:

	Plot('yumaIC_'+itag,'./2D_yuma_'+itag+'/imagenosmo.rsf','''
		pow pow1=0.325 | window min2=-22.5 max2=22.5 max1=22.5 | 
		%(RSF)s/sfgrey color=IC '''%par + greyplot)
	Flow('yumaIC_'+itag+'.eps','yumaIC_'+itag+'.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	Plot('yuma_'+itag,'./2D_yuma_'+itag+'/imagenosmo.rsf','''
		window min2=-22.5 max2=22.5 max1=22.5 | %(RSF)s/sfgrey '''%par + greyplot)
	Flow('yuma_'+itag+'.eps','yuma_'+itag+'.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)
	
	Plot('vst_'+itag,'./2D_yuma_'+itag+'/vst.rsf','''
		window min2=-22.5 max2=22.5 max1=22.5 | %(RSF)s/sfgrey color=j'''%par + greyplot)
	Flow('vst_'+itag+'.eps','vst_'+itag+'.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	Result('VShot_'+itag,'./2D_yuma_'+itag+'/VShot01.rsf','''
		window n2=361 min2=-36| %(RSF)s/sfgrey gainpanel=e title="" label1="Time" label2="Distance" unit1="s" unit2="m" labelsz=6 font=104 screenratio=2 pclip=99 '''%par + greyplot)
	Flow('VShot_'+itag+'.eps','VShot_'+itag+'.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	Result('scat_'+itag,'./2D_yuma_'+itag+'/scat01.rsf','''
		%(RSF)s/sfgrey gainpanel=e title="" label1="Time" label2="Distance" unit1="s" unit2="m" labelsz=6 font=104 screenratio=2 pclip=99'''%par + greyplot)
	Flow('scat_'+itag+'.eps','scat_'+itag+'.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	Result('tran_'+itag,'./2D_yuma_'+itag+'/tran01.rsf','''
		 %(RSF)s/sfgrey gainpanel=e title="" label1="Time" label2="Distance" unit1="s" unit2="m" labelsz=6 font=104 screenratio=2 pclip=99'''%par + greyplot)
	Flow('tran_'+itag+'.eps','tran_'+itag+'.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

End()
