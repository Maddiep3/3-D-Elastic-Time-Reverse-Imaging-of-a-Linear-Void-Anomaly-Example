from rsf.proj import *

par = {
 'RSF':'/sets/cwp/code/RSF/RSF4.2_CU12.9.1/bin/',
}

# . .vplot 
v2e = ' /sets/cwp/code/RSF/RSF4.2_CU12.9.1/bin/vplot2eps color=y invras=n '

greyplot = ' pclip=99.85 screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m labelsz=4 font=104 '

for itag in ['050','075','100','125','150']:
	Plot('vertgradIC_'+itag+'m','./2D_vertgrad_'+itag+'m/imagenosmo.rsf','''
		window min2=-20 max2=20 max1=20 | 
		%(RSF)s/sfgrey color=IC '''%par + greyplot)
	Flow('vertgradIC_'+itag+'m.eps','vertgradIC_'+itag+'m.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)

	Plot('vertgrad_'+itag+'m','./2D_vertgrad_'+itag+'m/imagenosmo.rsf','''
		window min2=-20 max2=20 max1=20 | %(RSF)s/sfgrey '''%par + greyplot)
	Flow('vertgrad_'+itag+'m.eps','vertgrad_'+itag+'m.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)
	
	Plot('vst_'+itag+'m','./2D_vertgrad_'+itag+'m/vst.rsf','''
		window min2=-20 max2=20 max1=20 | %(RSF)s/sfgrey color=j'''%par + greyplot)
	Flow('vst_'+itag+'m.eps','vst_'+itag+'m.vpl',v2e+'${SOURCES[0]} ${TARGETS[0]}',stdin=0,stdout=0)


End()
