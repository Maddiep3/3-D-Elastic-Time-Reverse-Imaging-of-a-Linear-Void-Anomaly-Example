#try:    from rsf.mycluster import *
#except: 
from rsf.proj import *

import geom,pcsutil,stiffness,fdmod

#Cluster(name='A',email=None,time=60,account=181219104004,partn='geop',ppn=12,nodetype='gpu',nsocket=4,gpu=False)

RSF=os.environ['RSFSRC']

# ------------------------------------------------------------
par = dict(
    nx=3200, ox=-160, dx=0.1,    lx='x', ux='m',
    ny=1,    oy=0, dy=0.1,       ly='y', uy='m',
    nz=1920,  oz=0, dz=0.1,       lz='z', uz='m',
    nt=30000, ot=0, dt=0.000024, lt='t', ut='s',
	nrx=1600,drx=0.2,orx=-160.0,
    labelsz=4, font=104,

	## . . Wavelet parameters
    kt=5000, # wavelet center
    frq=40,
    f1=5, f2=10, f3=50, f4=80, #f3=80, f4=150, 
    RSFSRC='/beegfs/sets/cwp/code/RSF/RSF4.2_CU12.9.1/RSFSRC/',
    CBIN=RSF+'/user/coren',
	CDIR='/beegfs/sets/cwp/code/RSF/RSF4.2_CU12.9.1/RSFSRC/user/coren2',

    # . . Modelling parameters
    zsou=0.5, # Source depth
    zrec=0.0, # Receiver depth
    verb='y', # verbosity flag
    free='y', # free surface flag
    ssou='n', # stress source flag
    nbell=5,  # bell size
    jdata=20, # extract receiver data every jdata time steps
    opot='n', # Potentials (separated P- and S-wave modes) can be computed if opot=y
    snap='y', # wavefield snapshots flag
    jsnap=20000,
    dabc='y', # absorbing boundary flag
    nb=160,
    
    # . . Processing pars
    nxpad=1600,
    d1=2.60417,
    
    ## .. ETRI parameters
	taper='y',
 	mtsou='n', 
 	ictype=4, 
 	eictype=1,

	# Plotting parameters   
	height=6,
	labelattr=' font=104 titlesz=4 titlefat=3 labelsz=5 labelfat=3'   
)


#for results
depthimg = ' color=n mean=y screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m  '
depthgrey = ' color=j mean=y screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m '
depthvel = ' scalebar=y barlabel="Velocity (m/s)" color=j bias=525 pclip=100 title="" label1="Depth" unit1=m label2=Distance unit2=m screenratio=0.3 screenht=4 '
pdepthvel = ' scalebar=y barlabel="Velocity (m/s)" color=j bias=1000 pclip=100 title="" label1="Depth" unit1=m label2=Distance unit2=m screenratio=0.3 screenht=4 '
sdepthvel = ' scalebar=y barlabel="Velocity (m/s)" color=j bias=500 pclip=100 title="" label1="Depth" unit1=m label2=Distance unit2=m screenratio=0.3 screenht=4 '


# ------------------------------------------------------------
# source coordinates (makes file with source coordinates)
#How would I add multiple sources?
par_shot=dict()


sindex=range(0,36)

# . . Source coordinates

for i in sindex:
	if i < 18:
	    ishot="%02d"%i
	    par['xsou'+ishot]=i*2-72  
	    geom.point2d('ss'+ishot,par['xsou'+ishot],par['zsou'],'',par)
	else:
	    ishot="%02d"%i
	    par['xsou'+ishot]=72-(i-18)*2  
	    geom.point2d('ss'+ishot,par['xsou'+ishot],par['zsou'],'',par)	

# . . Receiver coordinates
Flow('rx',None,'spike nsp=1600 mag=0.5 n1=1600 o1=-160 d1=0.2 |math output="x1" ')
Flow('rz','rx','math output="%(zrec)g" '%par)

# . . For EFD Modelling
Flow('rr','rx rz','cat axis=2 ${SOURCES[1]} | transp')

# . . For ETRI
Flow('rrcut','rr','window n2=361 min2=-36')

# ------------------------------------------------------------
#Build Lines 

pcsutil.angline('layer1', 1.3, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer2', 2.1, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer3', 3.5, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer4', 5.7, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer5', 10, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer6', 20, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer7', 23, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer8', 27.8, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer9', 29.7, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

pcsutil.angline('layer10', 32, 0, 0, 0, 1,
                par['nz']  ,par['oz'],par['dz'],
                par['nx'],par['ox'],par['dx'])

#tunnel lines
Flow('tunnel',None,'''
	math n1=21 n2=21 output="1" | 
	pad beg1=40 n1=%(nz)d beg2=1590 n2=%(nx)d | 
	put o1=%(oz)g o2=%(ox)g d1=%(dz)g d2=%(dx)g''' %par)

par['smrep']=5
par['smlen']=5

# ------------------------------------------------------------
# Density (kg/m^3)
cont=True

if cont:
	# . . Density
	Flow('ro','layer1','math l1=${SOURCES[0]} output="0*l1+1500" '%par)

	# P velocity (m/s)
	Flow('vp','layer1','math l1=${SOURCES[0]} output="0*l1+700+20.0*x1" | clip2 upper=1400'%par)

	# S velocity (m/s)
	Flow('vs','layer1','math l1=${SOURCES[0]} output="0*l1+400+20*x1" | clip2 upper=1000'%par)

else:
	# . . Density
	Flow('ro',['layer1','layer2','layer3','layer4','layer5','layer6','layer7','layer8','layer9','layer10'],'''
     	 math l1=${SOURCES[0]} l2=${SOURCES[1]} l3=${SOURCES[2]} l4=${SOURCES[3]} l5=${SOURCES[4]} l6=${SOURCES[5]} l7=${SOURCES[6]} l8=${SOURCES[7]} l9=${SOURCES[8]} l10=${SOURCES[9]} 
         output="l1*50 + l2*100 + l3*100 - l4*200 + l5*200 - l6*100 - l7*100 + l8*200 + l9*200 + l10*100" | 
         add add=1450 | smooth repeat=%(smrep)d rect1=%(smlen)d '''%par)

	# P velocity (m/s)
	Flow('vp',['layer1','layer2','layer3','layer4','layer5','layer6','layer7','layer8','layer9','layer10'],'''
     	 math l1=${SOURCES[0]} l2=${SOURCES[1]} l3=${SOURCES[2]} l4=${SOURCES[3]} l5=${SOURCES[4]} l6=${SOURCES[5]} l7=${SOURCES[6]} l8=${SOURCES[7]} l9=${SOURCES[8]} l10=${SOURCES[9]} 
         output="l1*150 + l2*140 + l3*160 - l4*90 + l5*235 - l6*245 - l7*60 + l8*60 + l9*350 +l10*100" | 
         add add=400 |  smooth repeat=%(smrep)d rect1=%(smlen)d '''%par)

	# S velocity (m/s)
	Flow('vs',['layer1','layer2','layer3','layer4','layer5','layer6','layer7','layer8','layer9','layer10'],'''
     	 math l1=${SOURCES[0]} l2=${SOURCES[1]} l3=${SOURCES[2]} l4=${SOURCES[3]} l5=${SOURCES[4]} l6=${SOURCES[5]} l7=${SOURCES[6]} l8=${SOURCES[7]} l9=${SOURCES[8]} l10=${SOURCES[9]} 
         output="l1*100 + l2*75 + l3*100 - l4*50 + l5*130 - l6*130 - l7*50 + l8*50 + l9*200 +l10*60" | 
         add add=225 |  smooth repeat=%(smrep)d rect1=%(smlen)d '''%par)

# . . Create 2D input stiffness tensor
Flow('CC0lambda','ro vp vs','math output="ro*(vp*vp-2*vs*vs)" ro=${SOURCES[0]} vp=${SOURCES[1]} vs=${SOURCES[2]}')
Flow('CC0mu',    'ro vp vs','math output="ro*vs*vs" ro=${SOURCES[0]} vp=${SOURCES[1]} vs=${SOURCES[2]}')
Flow('CC0-11','CC0lambda CC0mu','math l=${SOURCES[0]} m=${SOURCES[1]} output="l+2*m" ')
Flow('CC0-33','CC0lambda CC0mu','math l=${SOURCES[0]} m=${SOURCES[1]} output="l+2*m" ')
Flow('CC0-55','CC0lambda CC0mu','math l=${SOURCES[0]} m=${SOURCES[1]} output="    m" ')
Flow('CC0-13','CC0lambda CC0mu','math l=${SOURCES[0]} m=${SOURCES[1]} output="    l" ')

# . . combine the pieces to a single file
Flow('CC0','CC0-11 CC0-33 CC0-55 CC0-13','cat axis=3 space=n ${SOURCES[1:4]} ')

##########################
#
# . . models with tunnel
#
Flow('rot','ro tunnel','math t=${SOURCES[1]} output="input-t*20000" | sfclip2 lower=1000 '%par)
Flow('vpt','vp tunnel','math t=${SOURCES[1]} output="input-t*20000" | sfclip2 lower=330 '%par)
Flow('vst','vs tunnel','math t=${SOURCES[1]} output="input-t*20000" | sfclip2 lower=0   '%par)

# . . Create 2D input stiffness tensor for tunnel
Flow('CC0lambdat','rot vpt vst','math output="ro*(vp*vp-2*vs*vs)" ro=${SOURCES[0]} vp=${SOURCES[1]} vs=${SOURCES[2]}')
Flow('CC0mut'    ,'rot vpt vst','math output="ro*vs*vs" ro=${SOURCES[0]} vp=${SOURCES[1]} vs=${SOURCES[2]}')
Flow('CC0-11t','CC0lambdat CC0mut','math l=${SOURCES[0]} m=${SOURCES[1]} output="l+2*m" ')
Flow('CC0-33t','CC0lambdat CC0mut','math l=${SOURCES[0]} m=${SOURCES[1]} output="l+2*m" ')
Flow('CC0-55t','CC0lambdat CC0mut','math l=${SOURCES[0]} m=${SOURCES[1]} output="    m" ')
Flow('CC0-13t','CC0lambdat CC0mut','math l=${SOURCES[0]} m=${SOURCES[1]} output="    l" ')

# . . combine the pieces to a single file
Flow('CC0t','CC0-11t CC0-33t CC0-55t CC0-13t','cat axis=3 space=n ${SOURCES[1:4]} ')

# ------------------------------------------------------------
# elastic source
Flow('tmp',None,'''
         %(RSFSRC)s/user/utils/sformsby nt=%(nt)d dt=%(dt)g kt=%(kt)d f1=%(f1)g f2=%(f2)g f3=%(f3)g f4=%(f4)g |
         kolmog | pad n1=%(nt)d | put o1=0  |   transp |math output="input*1000000"'''%par) #JCS put in nplo and nphi
#         window min1=-0.1 | pad n1=%(nt)d | put o1=0  |   transp |math output="input*1000000"'''%par) #JCS put in nplo and nphi
Flow('one','tmp','window squeeze=n | math output="input*(1)"') #JCS was 0
Flow('two','tmp','window squeeze=n | math output="input*(0)"') #JCS was 1
Flow('wave','one two','''
     cat axis=1 space=n ${SOURCES[1]} |
     transp plane=23 |
     transp plane=12 |
     put label1="" unit1="" label2="" unit2="" ''')

## --------------------------------------------------
# . . Data Processing
par['ntcut']=par['nt']/par['jdata']/2+1

par['zero_cut']=par['nxpad']+15
par['one_cut']=2*par['nxpad']-par['zero_cut']
par['o2']= par['zero_cut']*0.00694444-0.5
Flow('m1',None,'math n1=%(ntcut)d d1=%(d1)g o1=0 n2=%(zero_cut)d d2=0.00694444 n3=1 d3=2 o2=-1 output="0"'%par)
Flow('m2',None,'math n1=%(ntcut)d d1=%(d1)g o1=0 n2=%(one_cut)d  d2=0.00694444 n3=1 d3=2 o2=%(o2)g output="1"'%par)
Flow('mask','m1 m2','cat axis=2 ${SOURCES[1]} | smooth rect2=5 repeat=5 | costaper nw2=30 | rtoc')
Flow('rmask','mask','math output="1-input" ')
#Flow('rmask','mask','reverse which=2 ')

par['zero_cut_neg']=par['nxpad']-10
par['one_cut_neg']=2*par['nxpad']-par['zero_cut_neg']
par['o2_neg']= par['zero_cut_neg']*0.00694444-0.5
Flow('nm1',None,'math n1=%(ntcut)d d1=%(d1)g o1=0 n2=%(zero_cut_neg)d d2=0.00694444 n3=1 d3=2 o2=-1 output="0"'%par)
Flow('nm2',None,'math n1=%(ntcut)d d1=%(d1)g o1=0 n2=%(one_cut_neg)d  d2=0.00694444 n3=1 d3=2 o2=%(o2_neg)g output="1"'%par)
Flow('nmask','nm1 nm2','cat axis=2 ${SOURCES[1]} | smooth rect2=5 repeat=5 | costaper nw2=30 | rtoc')
Flow('nrmask','nmask','reverse which=2 ')

fdmod.point('cip',0,10,par) # . . 2D Point Sources . . x and z coordinates of a source

for j in sindex:
	jss="%02d"%j
	par['jj']=j
	# ------------------------------------------------------------
	# elastic FDM

    # source wavefield (z,x,t) 
#         %(CDIR)s/sfewefd2dgpu.x
	Flow(['dpo'+jss,'wpo'+jss], ['wave','CC0t','rot','ss'+jss,'rr'],'''
 		 /beegfs/sets/cwp/code/RSF/RSF4.2_CU12.9.1/RSFSRC/user/rweiss/sfewefd2d_gpu
         wav=${SOURCES[0]} 
		 ccc=${SOURCES[1]}
         den=${SOURCES[2]}
         sou=${SOURCES[3]}
         rec=${SOURCES[4]}
         wfl=${TARGETS[1]}
         nt=%(nt)d jdata=%(jdata)d verb=%(verb)s free=%(free)s
         ssou=%(ssou)s opot=%(opot)s snap=%(snap)s jsnap=%(jsnap)d
         dabc=%(dabc)s nb=%(nb)d nbell=%(nbell)d wavSrc=y verb=y '''%par)

	Flow('VShot'+jss,'dpo'+jss,'''
		window n2=1 f2=0 | 
		transp | 
		put o2=%(orx)g | 
		bandpass flo=%(f1)g nplo=10 '''%par) 
	Result('VShot'+jss,'window n2=361 min2=-36| grey gainpanel=e title="DATA'+jss+'" labelsz=6 font=104 screenratio=2 grid=y g1num=50 g1num0=0 pclip=99')

	if j < 18:
		par['iloc'] = (j)*2-72
		par['lpad'] = 0#(j)*2*5

		Flow('positive'+jss,'VShot'+jss,'''
			 costaper nw2=10 nw1=10 |
			 pad n2=%(nxpad)g | fft1 | fft3 '''%par) 

		Flow('scat'+jss,['positive'+jss, 'mask'],'''
			math mask=${SOURCES[1]} output="input*mask"|
			fft3 inv=y |
			fft1 inv=y |
			window n2=%(nrx)g | put o2=%(orx)g |
			bandpass flo=%(f2)g nplo=10 | 
			mutter x0=%(iloc)g v0=1000 t0=0.02 tp=0.04 half=y outer=y |
			mutter v0=100000000 t0=0.08 tp=0.10 | 
			window min2=-36 max2=36'''%par)

		Flow('tran'+jss,['positive'+jss, 'rmask'],'''
			math mask=${SOURCES[1]} output="input*mask"|
			fft3 inv=y |
			fft1 inv=y |
			window n2=%(nrx)g | put o2=%(orx)g | 
			bandpass flo=%(f2)g nplo=10 | 
			window n2=361 min2=-36 '''%par)
	
	else:
		par['iloc'] = 36-(j-18)*2

			
		Flow('negative'+jss,'VShot'+jss,'''
			costaper nw2=10 nw1=10 |
			pad n2=%(nxpad)g | fft1 | fft3 '''%par)

		Flow('scat'+jss,['negative'+jss, 'nrmask'],'''
			math mask=${SOURCES[1]} output="input*mask"|
			fft3 inv=y |
			fft1 inv=y |
			window n2=%(nrx)g | put o2=%(orx)g | 
			bandpass flo=%(f2)g nplo=10 | 
			mutter x0=%(iloc)g v0=1000 t0=0.02 tp=0.04 half=y outer=y | 
			mutter v0=100000000 t0=0.08 tp=0.10 | 
			window n2=361 min2=-36'''%par)

		Flow('tran'+jss,['negative'+jss, 'nmask'],'''
			math mask=${SOURCES[1]} output="input*mask"|
			fft3 inv=y |
			fft1 inv=y |
			window n2=%(nrx)g | put o2=%(orx)g | 
			bandpass flo=%(f2)g nplo=10 | 
			window n2=361 min2=-36'''%par)

	Result('scat'+jss,'grey gainpanel=e title="SCAT'+jss+'" labelsz=6 font=104 screenratio=2 pclip=99.9 grid=y g1num=50 g1num0=0')
	Result('tran'+jss,'grey gainpanel=e title="TRAN'+jss+'" labelsz=6 font=104 screenratio=2 pclip=99.9 grid=y g1num=50 g1num0=0')


##############################
#
# . . ETRI section

	## . . Interpolate back to original grid
	## . . The halfint calls change the phase of the image by 90º so that the
	## . . maximum of the ETRI anomaly is located at the center of the anomaly (not a zero crossing)
	Flow('DU-z'+jss,'scat'+jss,'sinc n1=%(nt)d o1=%(ot)g d1=%(dt)g | halfint inv=y adj=y | window max1=0.4 | transp memsize=20000'%par)
	Flow('U0-z'+jss,'tran'+jss,'sinc n1=%(nt)d o1=%(ot)g d1=%(dt)g | halfint inv=y adj=n | window max1=0.4 | transp memsize=20000'%par) 

	## . . Null files for horizontals
	Flow('U0-x'+jss,'U0-z'+jss,'math output="0"')
	Flow('DU-x'+jss,'DU-z'+jss,'math output="0"')
	
	# . . Use vertically smoothed E-FWI model 
	Flow(['imagesmo'+jss,'eicsmo'+jss,'bwpssmo'+jss],
		['CC0','ro','rrcut','DU-z'+jss,'DU-x'+jss,'U0-z'+jss,'U0-x'+jss,'cip'],'''
		%(CDIR)s/sfefdtrips2dgpu.x
		jdata=%(jdata)d dabc=%(dabc)s free=y 
		verb=y snap=%(snap)s jsnap=%(jsnap)d nb=%(nb)d nbell=%(nbell)d tmin=0.025 tmax=0.3
		opot=%(opot)s ictype=%(ictype)d eictype=%(eictype)d ncip=1 cipz=1 cipz=1 lhz=0. lhx=0. taper=y 
		den=${SOURCES[1]}
		rec=${SOURCES[2]}
		datpz=${SOURCES[3]}
		datpx=${SOURCES[4]}
		datsz=${SOURCES[5]}
		datsx=${SOURCES[6]}		
		cip=${SOURCES[7]}
		eimg=${TARGETS[1]}
		bwfl=${TARGETS[2]} 
 		''' % par)

	Flow('ismo'+jss,'imagesmo'+jss,'''
		put n3=1 unit1=m unit2=m label1=Depth label2=Distance | pow pow1=1 | 
		window min2=-25 max2=25 min1=0 max1=25 '''%par)

	Result('ismo'+jss,'''
		grey pclip=99.85 screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m ''' +par['labelattr'])

	
#stostack=["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35"]

Flow('imagesmo'  , ['ismo%02d.rsf'%rexp for rexp in sindex], 'sfadd ${SOURCES[1:36]}| laplace | window | pow pow1=1')
Flow('imagenosmo', ['ismo%02d.rsf'%rexp for rexp in sindex], 'sfadd ${SOURCES[1:36]}          | window| pow pow1=1')  

Result('imagesmo',  '''
	grey pclip=99.95 screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m labelsz=4 font=104 ''' +depthimg+par['labelattr'])

Result('imagenosmo','''
	grey pclip=99.95 screenratio=0.5 screenht=5 title="" label1="Depth" unit1=m label2=Distance unit2=m labelsz=4 font=104 ''' +depthimg+par['labelattr'])


End()
